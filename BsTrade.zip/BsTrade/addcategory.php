<?php
	include('config.php');

	$cname=$_POST['cname'];

	$sql="INSERT INTO category (catname) VALUES ('$cname')";
	$conn->query($sql);

	header('location:category.php');

?>