<?php
	include('config.php');

	$id=$_GET['user'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$type = $_POST['type'];




	$sql="select * from users where id='$id'";
	$query=$conn->query($sql);




	if ($_POST['password']!= "") {
		// récupérer le mot de passe et supprimer les antislashes ajoutés par le formulaire
		$password = stripslashes($_POST['password']);
		$password = mysqli_real_escape_string($conn, $password);
		
		$row=$query->fetch_array();

		$sql="update users set username='$username', email='$email', type='$type', password='".hash('sha256', $password)."' where id='$id'";

	}else{
		$row=$query->fetch_array();

		$sql="update users set username='$username', email='$email', type='$type' where id='$id'";
	}



	$conn->query($sql);
	header('location:user.php');

?>