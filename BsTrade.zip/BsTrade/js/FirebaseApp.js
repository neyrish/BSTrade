import { initializeApp } from 'firebase/app';


import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged } from "firebase/auth";



// TODO: Replace the following with your app's Firebase project configuration
const firebaseConfig = {
    apiKey: "AIzaSyArF7aQ2z18nIi6ELX80wSdeB89jT8A6zQ",
    authDomain: "treecorp-bstrade-project-app.firebaseapp.com",
    databaseURL: "https://treecorp-bstrade-project-app-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "treecorp-bstrade-project-app",
    storageBucket: "treecorp-bstrade-project-app.appspot.com",
    messagingSenderId: "630722860534",
    appId: "1:630722860534:web:de558423c6c59a19b223d7",
    measurementId: "G-RQGQ82ZL11"
};

function emailConnection() {
  var emailAdresse = document.getElementById('log_username').value
  var password = document.getElementById('lob_password').value


signInWithEmailAndPassword(auth, emailAdresse, password)
  .then((userCredential) => {
    // Signed in 
    const user = userCredential.user;
    alert (user);
    print(user);
  })
  .catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
    alert(error);
    print(error);
  });

}
document.getElementById ('boutonConnexion').addEventListener("click", emailConnection());

  onAuthStateChanged(auth, (user) => {
    if (user) {
      // User is signed in, see docs for a list of available properties
      // https://firebase.google.com/docs/reference/js/firebase.User
      const uid = user.uid;
      // ...
    } else {
      // User is signed out
      // ...
    }
  });
   createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      // Signed in 
      const user = userCredential.user;
      // ...
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      // ..
    });
    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);



