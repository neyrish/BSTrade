<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>
	<div class="login-form">
<?php
require('config.php');
session_start();
$message=2;
if (isset($_POST['mdp'])){

	$id = $_SESSION['id'];
	$mdp = stripslashes($_REQUEST['mdp']);
	$confirm_mdp = stripslashes($_REQUEST['confirm_mdp']);

	if ($mdp == $confirm_mdp AND !empty($mdp)){

		$sql="select * from users where id='$id'";
		$query=$conn->query($sql);
		$row=$query->fetch_array();
		$sql="update users set password='".hash('sha256', $mdp)."' where id='$id' ";
		$conn->query($sql);
		$message = 1;
	}else{
		$message = 0;
	}
}
?>
<?php
if(isset($_SESSION['id']) AND isset($_SESSION['username']))
{
?>
	<form class="box" action="" method="post" name="change_mdp">
	<p class="box-logo box-title"><a href="index.php"> Nom d'utilisateur : <?php echo $_SESSION['username'] ?></a></p>

	<p class="box-title">Changer le mot de passe ? </p>
	<input type="password" class="box-input" name="mdp" placeholder="Nouveau mot de passe">
	<input type="password" class="box-input" name="confirm_mdp" placeholder="Confirmation du mot de passe">
	<input type="submit" value="Connexion " name="submit" class="box-button">
	<p class="box-register">Vous souhaitez retourné en arrières ?<a href="index.php" class="btn ">Accueil</a></p>
	<?php
	if ($message==1) {
			?>
			<!-- Success Alert -->
			<div class="alert alert-success" style="background: lightgreen;">
			  <strong>Succès !</strong> Le mot de passe a été mis à jour.
			</div>
		<?php
		sleep(5);
		header("location:index.php");
	}elseif($message==0){
	   ?>
	<!-- Error Alert -->
		<div class="alert alert-danger" style="background: red;">
		  <strong>Erreur !</strong> Le mot de passe dois etre identique.
		</div>
	<?php
	}
	?>
	<?php
}else{
		header("location: login.php");
    }
	?>
<p class="box-register">Vous souhaitez vous déconnecter ?  <a href="logout.php" class="btn">Se Déconnecter</a></p>



</form>
</div>
<style>
	 .login-form {
                width: 340px;
                margin: 50px auto;
				background-image: url("./img/logo.png");
				
            }
            .login-form form {
                margin-bottom: 15px;
                background: #7EBF88;
                box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
                padding: 30px;
            }
			.login-form img {
				width: 150px;
				height: 150px ; 
				position : relative;
				box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.3);
				margin-left : 55px; 

			}
           .login-form p{
			   color:white;

		   }


			
            .form-control, .btn {
                min-height: 38px;
                border-radius: 2px;
            }
            .btn {        
               
    min-width: 145px;
    line-height: 50px;
    padding: 0 30px;
    font-size: 16px;
    font-weight: 600;
    text-transform: uppercase;
    border-radius: 0;
    transition: box-shadow 0.25s ease-in-out;
    -moz-transition: box-shadow 0.25s ease-in-out;
    -webkit-transition: box-shadow 0.25s ease-in-out;
    -o-transition: box-shadow 0.25s ease-in-out;
    -ms-transition: box-shadow 0.25s ease-in-out;
            }




</style>
</body>
</html>