﻿<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="login-form">
	<?php
	require('config.php');
	session_start();

	if (isset($_POST['username'])){
		$username = stripslashes($_REQUEST['username']);
		$username = mysqli_real_escape_string($conn, $username);
		$_SESSION['username'] = $username;
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($conn, $password);
    	$query = "SELECT * FROM `users` WHERE username='$username' and password='".hash('sha256', $password)."'";
		$result = mysqli_query($conn,$query) or die(mysql_error());
	
		if (mysqli_num_rows($result) == 1) {
		$user = mysqli_fetch_assoc($result);
		// vérifier si l'utilisateur est un administrateur ou un utilisateur
			if ($user['type'] == 'admin') {
			header('location: index.php');	  
			}else{
			header('location: index.php');
		}
		$_SESSION['type'] = $user['type'];
		$_SESSION['id'] = $user['id'];
		}else{
		$message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
		}
	}
		?>
		<form class="box" action="" method="post" name="login">
			
		<img src="img/logo.png" alt= "logo de BS Trade">
		<h1 class="box-logo box-title"><a href="">BsTrade</a></h1>
		<br>
			<h2 class="box-title">Connexion</h2>
				<input type="text" class="box-input" name="username" placeholder="Nom d'utilisateur">
				
				<br>
				<input type="password" class="box-input" name="password" placeholder="Mot de passe">
				<br>
				<input type="submit" value="Connexion " name="submit" class="box-button">
				<p class="box-register">Vous êtes nouveau ici? <a href="register.php">S'inscrire</a></p>
				<?php if (! empty($message)) { ?>
    			<p class="errorMessage"><?php echo $message; ?></p>
				<?php } ?>
		</form>
</div>
<style>
            .login-form {
                width: 340px;
                margin: 50px auto;
				background-image: url("./img/logo.png");
				
            }
            .login-form form {
                margin-bottom: 15px;
                background: #7EBF88;
                box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
                padding: 30px;
            }
			.login-form img {
				width: 150px;
				height: 150px ; 
				position : relative;
				box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.3);
				margin-left : 55px; 

			}
            .login-form h1 {
                margin: 0 0 15px;
				color: white;
				text-align: center;
            }
			.loging-form h2{
				margin: 0 0 15px;
				color: white;

			}
            .form-control, .btn {
                min-height: 38px;
                border-radius: 2px;
            }
            .btn {        
                font-size: 15px;
                font-weight: bold;
            }
        </style>
</body>
</html>