﻿<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
require('config.php');
session_start();

if (isset($_POST['username'])){
	// récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
	$username = stripslashes($_REQUEST['username']);
	$username = mysqli_real_escape_string($conn, $username);
	$_SESSION['username'] = $username;
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($conn, $password);
	$c_password = stripslashes($_REQUEST['c_password']);
	$c_password = mysqli_real_escape_string($conn, $c_password);
	if ($password==$c_password) {
		// récupérer l'email et supprimer les antislashes ajoutés par le formulaire
		$email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($conn, $email);
		// récupérer le mot de passe et supprimer les antislashes ajoutés par le formulaire
		// récupérer le type (user | admin)
		$type = "user";
		
	    $query = "INSERT into `users` (username, email, type, password)
					  VALUES ('$username', '$email', '$type', '".hash('sha256', $password)."')";
	    $res = mysqli_query($conn, $query);
		$_SESSION['type'] = $user['type'];
		$_SESSION['id'] = $user['id'];
	    header('location: index.php');
	}else{
		$message = "Le mot de passe n'est pas identique";
	}
}
?>
<form class="box" action="" method="post" name="login">
<h1 class="box-logo box-title"><a href="">BsTrade</a></h1>
<h1 class="box-title">Inscription</h1>
<input type="text" class="box-input" name="username" placeholder="Nom d'utilisateur">
<input type="text" class="box-input" name="email" placeholder="Email">
<input type="password" class="box-input" name="password" placeholder="Mot de passe">
<input type="password" class="box-input" name="c_password" placeholder="Confirmation du mot de passe">
<input type="submit" value="S'inscrire " name="submit" class="box-button">
<p class="box-register">Vous avez déja un compte? <a href="login.php">Connexion</a></p>
<?php if (! empty($message)) { ?>
    <p class="errorMessage"><?php echo $message; ?></p>
<?php } ?>
</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.js"></script>  
  <!-- SmartMenus jQuery plugin -->
  <script type="text/javascript" src="js/jquery.smartmenus.js"></script>
  <!-- SmartMenus jQuery Bootstrap Addon -->
  <script type="text/javascript" src="js/jquery.smartmenus.bootstrap.js"></script>  
  <!-- To Slider JS -->
  <script src="js/sequence.js"></script>
  <script src="js/sequence-theme.modern-slide-in.js"></script>  
  <!-- Product view slider -->
  <script type="text/javascript" src="js/jquery.simpleGallery.js"></script>
  <script type="text/javascript" src="js/jquery.simpleLens.js"></script>
  <!-- slick slider -->
  <script type="text/javascript" src="js/slick.js"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="js/nouislider.js"></script>
  <!-- Custom js -->
  <script src="js/custom.js"></script> 

  <script type="text/javascript" src="js/db.js"></script>
</body>
</html>