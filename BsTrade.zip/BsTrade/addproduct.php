<?php
	include('config.php');

	
	session_start();
	$pname=$_POST['pname'];
	$price=$_POST['price'];
	$category=$_POST['category'];
	$photo=$_POST['photo'];
	$type=$_POST['type'];
	$id=$_SESSION['id'];
	if(isset($_FILES['photo'])){
		$tmpName = $_FILES['photo']['tmp_name'];
		$name = $_FILES['photo']['name'];
		$size = $_FILES['photo']['size'];
		$error = $_FILES['photo']['error'];
		move_uploaded_file($tmpName, './upload', $name);
		$req = $conn->prepare('INSERT INTO image (name) VALUES (?)');
		$req->execute([$photo]);
		echo "Image enregistré";
	

			}else{echo "erreur";}
	

			
	
	$sql="INSERT INTO product (productname,typeid, categoryid, price, photo,  vendeurid) VALUES ('$pname','$type', '$category', '$price', '$photo',  '$id')";
	$conn->query($sql);

	header('location:product.php');

?>
 