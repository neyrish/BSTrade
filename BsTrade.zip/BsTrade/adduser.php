<?php
	include('config.php');


	// récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
	$username = stripslashes($_POST['username']);
	$username = mysqli_real_escape_string($conn, $username); 
	// récupérer l'email et supprimer les antislashes ajoutés par le formulaire
	$email = stripslashes($_POST['email']);
	$email = mysqli_real_escape_string($conn, $email);
	// récupérer le mot de passe et supprimer les antislashes ajoutés par le formulaire
	$password = stripslashes($_POST['password']);
	$password = mysqli_real_escape_string($conn, $password);
	// récupérer le type (user | admin)
	$type = stripslashes($_POST['type']);
	$type = mysqli_real_escape_string($conn, $type);
	
    $query = "INSERT into `users` (username, email, type, password)
				  VALUES ('$username', '$email', '$type', '".hash('sha256', $password)."')";
    $res = mysqli_query($conn, $query);

	header('location:user.php');

?>