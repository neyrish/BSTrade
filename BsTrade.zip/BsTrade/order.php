<?php include('header.php'); ?>
<body>
<?php include('navbar.php'); ?>
<link rel="stylesheet" type="text/css" href="css/table.css">
<div class="container">
	<h1 class="page-header text-center">COMMANDER</h1>













	<div class="row">
		<div class="col-md-12">
			<select id="catList" class="btn btn-default" style="margin-right:5%; margin-left: 35%;">
			<option value="0">Toutes catégories</option>
			<?php
				$sql="select * from category";
				$catquery=$conn->query($sql);
				while($catrow=$catquery->fetch_array()){
					$catid = isset($_GET['category']) ? $_GET['category'] : 0;
					$selected = ($catid == $catrow['categoryid']) ? " selected" : "";
					echo "<option$selected value=".$catrow['categoryid'].">".$catrow['catname']."</option>";
				}
			?>
			</select>
		</div>
	</div>
	<div style="margin-top:20px;">






	<form method="POST" action="purchase.php">
		<table class="table table-striped table-bordered">
			<thead>
				<th class="text-center" style="display: none;"><input type="checkbox" id="checkAll" checked></th>
				<th>Catégorie</th>
				<th>Nom du produit</th>
				<th>Photo</th>
				<th>Prix</th>
				<th>Quantité</th>
			</thead>
			<tbody>
				<?php 
					$where = "";
					if(isset($_GET['category']) AND ($_GET['category']!=0))
					{
						$catid=$_GET['category'];
						$where = " WHERE product.categoryid = $catid";
					}elseif(isset($_GET['category']) AND ($_GET['category']!=0))
					{
						$catid=$_GET['category'];
						$where = " WHERE product.categoryid = $catid";
					}
					$sql="select * from product left join category on category.categoryid=product.categoryid $where order by product.categoryid asc, productname asc";
					$query=$conn->query($sql);
					$iterate=0;
					while($row=$query->fetch_array()){
						?>
						<tr id="table-active">
							<td class="text-center" style="display: none;"><input type="checkbox" value="<?php echo $row['productid']; ?>||<?php echo $iterate; ?>" name="productid[]" style="" checked></td>
							<td><?php echo $row['catname']; ?></td>
							

							<td><?php echo $row['productname']; ?></td>

							<td class="text-center"><img src="<?php if(empty($row['photo'])){echo "upload/noimage.jpg";} else{echo $row['photo'];} ?>" height="70px;" width="100px;"></td>


							<td class="text-right"><?php echo number_format($row['price'], 2); ?>€</td>
							<td width="30px"><input type="number" min="0" class="form-control" name="quantity_<?php echo $iterate; ?>" autocomplete="off" id="input-active"></td>
						</tr>
						<?php
						$iterate++;
					}
				?>

			</tbody>
		</table>
		







		<div class="row" style="margin-bottom:20%; margin-left: 20%; margin-top: 10%;">
			<div class="col-md-3">
				<input type="text" name="customer" class="form-control" placeholder="Nom du client" required autocomplete="off">
			</div>
			<div class="col-md-4" style="margin-left:-20px;">
				<input type="text" name="adresse" class="form-control" placeholder="Adresse du chantier" required autocomplete="off">
			</div>
			<div class="col-md-2" style="margin-left:-20px;">
				<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span>  Envoyer !</button>
			</div>
		</div>







	</form>
</div>
<script type="text/javascript">
	document.addEventListener("wheel", function(event){
    if(document.activeElement.type === "number"){
        document.activeElement.blur();
    	}
	});
	$(document).ready(function(){
		$("#checkAll").click(function(){
	    	$('input:checkbox').not(this).prop('checked', this.checked);
		});
		$("#catList").on('change', function(){
				var selectElmt = document.getElementById("typeList");
				var valeurselectionnee = selectElmt.options[selectElmt.selectedIndex].value;

				window.location = 'order.php?category='+$(this).val();
		});
	});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.js"></script>  
  <!-- SmartMenus jQuery plugin -->
  <script type="text/javascript" src="js/jquery.smartmenus.js"></script>
  <!-- SmartMenus jQuery Bootstrap Addon -->
  <script type="text/javascript" src="js/jquery.smartmenus.bootstrap.js"></script>  
  <!-- To Slider JS -->
  <script src="js/sequence.js"></script>
  <script src="js/sequence-theme.modern-slide-in.js"></script>  
  <!-- Product view slider -->
  <script type="text/javascript" src="js/jquery.simpleGallery.js"></script>
  <script type="text/javascript" src="js/jquery.simpleLens.js"></script>
  <!-- slick slider -->
  <script type="text/javascript" src="js/slick.js"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="js/nouislider.js"></script>
  <!-- Custom js -->
  <script src="js/custom.js"></script> 

  <script type="text/javascript" src="js/db.js"></script>
</body>
</html>