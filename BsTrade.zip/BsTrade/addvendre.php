<?php
	include('config.php');
	session_start();
	$pname=$_POST['pname'];
	$price=$_POST['price'];
	$category=$_POST['category'];
	$photo=$_FILES['photo'];
	$type=$_POST['type'];
	$id=$_SESSION['id'];
	
			$sql="INSERT INTO product (productname,typeid, categoryid, price, photo,  vendeurid) VALUES ('$pname','$type', '$category', '$price', '$photo',  '$id')";
		$conn->query($sql);
	
	

	header('location:vendre.php');

?>