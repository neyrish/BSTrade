<?php
// Informations d'identification
define('DB_SERVER', 'mysql-bstrade.alwaysdata.net');
define('DB_USERNAME', 'bstrade');
define('DB_PASSWORD', 'BsTrade69400@');
define('DB_NAME', 'bstrade_test');
 
// Connexion � la base de donn�es MySQL 
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// V�rifier la connexion
if($conn === false){
    die("ERREUR : Impossible de se connecter. " . mysqli_connect_error());
}
?>