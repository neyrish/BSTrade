﻿<?php include('header.php'); ?>
<body>
 <style>
      body {
        background-color: #7EBF88;
      }
    </style>
<?php include('navbar.php'); ?>
<div class="container">






	<h1 class="page-header text-center">ACCUEIL</h1>
	<ul class="nav nav-tabs">
		<?php
			$sql="select * from category order by categoryid asc limit 1";
			$fquery=$conn->query($sql);
			$frow=$fquery->fetch_array();
			?>
				<li class="active"><a data-toggle="tab" href="#<?php echo $frow['catname'] ?>"><?php echo $frow['catname'] ?></a></li>
			<?php

			$sql="select * from category order by categoryid asc";
			$nquery=$conn->query($sql);
			$num=$nquery->num_rows-1;

			$sql="select * from category order by categoryid asc limit 1, $num";
			$query=$conn->query($sql);
			while($row=$query->fetch_array()){
				?>
				<li><a data-toggle="tab" href="#<?php echo $row['catname'] ?>"><?php echo $row['catname'] ?></a></li>
				<?php
			}
		?>
	</ul>




	<div class="tab-content">
		<?php
			$sql="select * from category order by categoryid asc limit 1";
			$fquery=$conn->query($sql);
			$ftrow=$fquery->fetch_array();
			?>
				<div id="<?php echo $ftrow['catname']; ?>" class="tab-pane fade in active" style="margin-top:20px;">
					<?php

						$sql="select * from product where categoryid='".$ftrow['categoryid']."'";
						$pfquery=$conn->query($sql);
						$inc=4;
						while($pfrow=$pfquery->fetch_array()){
							$inc = ($inc == 4) ? 1 : $inc+1; 
							if($inc == 1) echo "<div class='row'>"; 
							?>
								<div class="col-md-3">
									<div class="panel panel-default">
										<div class="panel-heading text-center">
											<b><?php echo $pfrow['productname']; ?></b>
										</div>
										<div class="panel-body">
											<img src="<?php if(empty($pfrow['photo'])){echo "upload/noimage.jpg";} else{echo $pfrow['photo'];} ?>" height="225px;" width="100%">
										</div>
										<div class="panel-footer text-center">
											<?php echo number_format($pfrow['price'], 2);?>€
											<br><br>
											<form method="GET" action="buy_index.php?product=<?$prow['productid'];?>">
											<button type="submit" class="btn btn-primary" name="button"><span class="glyphicon glyphicon-floppy-disk"></span>  Acheter !</button>
										</form>
										</div>
									</div>
								</div>
							<?php
							if($inc == 4) echo "</div>";
						}
						if($inc == 1) echo "<div class='col-md-3'></div><div class='col-md-3'></div><div class='col-md-3'></div></div>"; 
						if($inc == 2) echo "<div class='col-md-3'></div><div class='col-md-3'></div></div>"; 
						if($inc == 3) echo "<div class='col-md-3'></div></div>";
						
					?>
		    	</div>
			<?php

			$sql="select * from category order by categoryid asc";
			$tquery=$conn->query($sql);
			$tnum=$tquery->num_rows-1;

			$sql="select * from category order by categoryid asc limit 1, $tnum";
			$cquery=$conn->query($sql);
			while($trow=$cquery->fetch_array()){
				?>
				<div id="<?php echo $trow['catname']; ?>" class="tab-pane fade" style="margin-top:20px;">
					<?php

						$sql="select * from product where categoryid='".$trow['categoryid']."'";
						$pquery=$conn->query($sql);
						$inc=4;
						while($prow=$pquery->fetch_array()){
							$inc = ($inc == 4) ? 1 : $inc+1; 
							if($inc == 1) echo "<div class='row'>"; 
							?>
								<div class="col-md-3">
									<div class="panel panel-default">
										<div class="panel-heading text-center">
											<b><?php echo $prow['productname']; ?></b>
										</div>
										<div class="panel-body">
											<img src="<?php if($prow['photo']==''){echo "upload/noimage.jpg";} else{echo $prow['photo'];} ?>" height="225px;" width="100%">
										</div>
										<div class="panel-footer text-center">
											<?php echo number_format($prow['price'], 2); ?>€
											<br><br>
											<form method="GET" action="buy_index.php?product=<?$prow['productid'];?>">
											<button type="submit" class="btn btn-primary" name="button"><span class="glyphicon glyphicon-floppy-disk"></span>  Acheter !</button>
										</form>
										</div>
									</div>
								</div>
							<?php
							if($inc == 4) echo "</div>";
						}
						if($inc == 1) echo "<div class='col-md-3'></div><div class='col-md-3'></div><div class='col-md-3'></div></div>"; 
						if($inc == 2) echo "<div class='col-md-3'></div><div class='col-md-3'></div></div>"; 
						if($inc == 3) echo "<div class='col-md-3'></div></div>"; 
					?>
		    	</div>
				<?php
			}
		?>
	</div>
	
</div>
<section id="aa-testimonial">  
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-testimonial-area">
            <ul class="aa-testimonial-slider">
              <!-- single slide -->
              <li>
                <div class="aa-testimonial-single">
                <img class="aa-testimonial-img" src="img/testimonial/1.png" alt="testimonial img">
                  <span class="fa fa-quote-left aa-testimonial-quote"></span>
                  <p>"Durant toute la durée de ce projet, j'ai pu découvrir en profondeur ce qu'est le travail d'équipe en
                    entreprise. Cette expérience mas permis d'approfondir mes compétences en informatique avec la création a partir de 0
                    de toute l'infrastructure d'une entreprise. Les obstacles rencontrés lors du projet m'on permis de grandir et
                    de devenir plus performant."</p>
                  <div class="aa-testimonial-info">
                    <p> Nathan </p>
                    <span> Responsable Communication </span>
                    <a href="#"></a>
                  </div>
                </div>
              </li>
              <!-- single slide -->
              <li>
                <div class="aa-testimonial-single">
                <img class="aa-testimonial-img" src="img/testimonial/4.png" alt="testimonial img">
                  <span class="fa fa-quote-left aa-testimonial-quote"></span>
                  <p>"Travailler chez TreeCorp. a été très gratifiant.
                    Ce projet m'a permis de surmonter plusieurs challenges.
                    En effet, assurer le respect de la RGPD m'a demandé une grande cohésion avec les équipes.
                    De plus, la dimension écologique, en donnant une seconde vie aux objets, me touche"</p>
                  <div class="aa-testimonial-info">
                    <p> William</p>
                    <span> CEO </span>
                    <a href="#">Alphabet</a>
                  </div>
                </div>
              </li>
               <!-- single slide -->
              <li>
                <div class="aa-testimonial-single">
                <img class="aa-testimonial-img" src="img/testimonial/3.png" alt="testimonial img">
                  <span class="fa fa-quote-left aa-testimonial-quote"></span>
                  <p>"Travailler chez TreeCorp. a été très gratifiant.
                    Ce projet m'a permis de surmonter plusieurs challenges.
                    En effet, assurer le respect de la RGPD m'a demandé une grande cohésion avec les équipes.
                    De plus, la dimension écologique, en donnant une seconde vie aux objets, me touche"</p>
                  <div class="aa-testimonial-info">
                    <p>Pierrick</p>
                    <span> Technicien Réseau</span>
                    <a href="#"></a>
                  </div>
                </div>
              </li>
               <!-- single slide -->
              <li>
                <div class="aa-testimonial-single">
                <img class="aa-testimonial-img" src="img/testimonial/2.png" alt="testimonial img">
                  <span class="fa fa-quote-left aa-testimonial-quote"></span>
                  <p>"Travailler chez TreeCorp. a été très gratifiant.
                    Ce projet m'a permis de surmonter plusieurs challenges.
                    En effet, assurer le respect de la RGPD m'a demandé une grande cohésion avec les équipes.
                    De plus, la dimension écologique, en donnant une seconde vie aux objets, me touche"</p>
                  <div class="aa-testimonial-info">
                    <p> Oktay </p>
                    <span> Responsable Réseau </span>
                    <a href="#">Alphabet</a>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- / Testimonial -->



  <footer id="aa-footer">
    <!-- footer bottom -->
    <div class="aa-footer-top">
     <div class="container">
        <div class="row">
        <div class="col-md-12">
          <div class="aa-footer-top-area">
            <div class="row">
              <div class="col-md-3 col-sm-6">
                <div class="aa-footer-widget">
                  <h3>Menu principal</h3>
                  <ul class="aa-footer-nav">
                    <li><a href="index.html">Accueil</a></li>
                    <li><a href="product.html">Publications</a></li>
                    <li><a href="#">Qui sommes-nous ?</a></li>
                    <li><a href="contact.html">Contactez-nous !</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="aa-footer-widget">
                  <div class="aa-footer-widget">
                    <h3>Contactez-nous !</h3>
                    <address>
                      <p> 96 Rue Henri Depagneux, 69400 Limas</p>
                      <p><span class="fa fa-phone"></span>04 81 15 01 40</p>
                      <p><span class="fa fa-envelope"></span>contact.bst69@gmail.com</p>
                    </address>
                    </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="aa-footer-widget">
                  <div class="aa-footer-widget">
                    <center><h3>Localisation</h3></center>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2772.710061810195!2d4.7166925!3d45.9770502!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f4854041dd3785%3A0xb3271f3228e2ed39!2sBusiness%20School%20by%20CSND!5e0!3m2!1sfr!2sfr!4v1649150709122!5m2!1sfr!2sfr" width="200%" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
               </div>
            </div>
          </div>
        </div>
      </div>
     </div>
    </div>
    <!-- footer-bottom -->
    <div class="aa-footer-bottom">
      <div class="container">
        <div class="row">
        <div class="col-md-12">
          <div class="aa-footer-bottom-area">
            <p>Copyright <a href="https://www.bs-beaujolais.fr/">Business School</a></p>
          </div>
        </div>
      </div>
      </div>
    </div>
  </footer>
  <!-- / footer -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.js"></script>  
  <!-- SmartMenus jQuery plugin -->
  <script type="text/javascript" src="js/jquery.smartmenus.js"></script>
  <!-- SmartMenus jQuery Bootstrap Addon -->
  <script type="text/javascript" src="js/jquery.smartmenus.bootstrap.js"></script>  
  <!-- To Slider JS -->
  <script src="js/sequence.js"></script>
  <script src="js/sequence-theme.modern-slide-in.js"></script>  
  <!-- Product view slider -->
  <script type="text/javascript" src="js/jquery.simpleGallery.js"></script>
  <script type="text/javascript" src="js/jquery.simpleLens.js"></script>
  <!-- slick slider -->
  <script type="text/javascript" src="js/slick.js"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="js/nouislider.js"></script>
  <!-- Custom js -->
  <script src="js/custom.js"></script> 

  <script type="text/javascript" src="js/db.js"></script>
</body>
</html>