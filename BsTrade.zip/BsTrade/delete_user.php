<?php
	include('config.php');

	$id = $_GET['user'];

	$sql="delete from users where id='$id'";
	$conn->query($sql);

	header('location:user.php');
?>